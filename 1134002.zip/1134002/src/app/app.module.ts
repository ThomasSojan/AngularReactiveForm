import { SkyHighService } from './sky-high/sky-high.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SkyHighComponent } from './sky-high/sky-high.component';
import { HomeComponent } from './home/home.component';
import { BookingSuccessPipe } from './sky-high/success.pipe';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    SkyHighComponent,
    BookingSuccessPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [SkyHighService],
  bootstrap: [AppComponent]
})
export class AppModule { }
