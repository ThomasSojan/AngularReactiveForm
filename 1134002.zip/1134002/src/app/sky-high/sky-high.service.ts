import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { throwError, Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { SkyHigh } from './skyHigh';

@Injectable()
export class SkyHighService {

  constructor(private http: HttpClient) { }

  book(data:SkyHigh) : Observable<SkyHigh> {
    
    return this.http.post<SkyHigh>('http://localhost:3333/jump/book', data);
    
  }

}

// thomas

