import { Pipe, PipeTransform } from '@angular/core';
import { SkyHigh } from './skyHigh';

@Pipe({
  name: 'bookingSuccess'
})
export class BookingSuccessPipe implements PipeTransform {

  transform(response: SkyHigh): string {
   return  "Thanks for choosing us : Your jump is scheduled on "+response.dateOfJump+" with id as "+response.jumpId;
  }
        

}