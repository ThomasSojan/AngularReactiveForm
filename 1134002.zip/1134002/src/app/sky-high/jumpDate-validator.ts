import { AbstractControl } from "@angular/forms";

//Validator class to validate the dateOfJump
export class JumpDateValidator {
/*method to check dateOfJump is a future date*/
static checkDateOfJump(dateOfJump: AbstractControl): { 'checkDate': true } | null {
let value = "" + dateOfJump.value;
let date:Date=new Date();
let jumpDate:Date=new Date(value);
if(jumpDate <= date )
{
return { 'checkDate': true };
}
return null;
}
}