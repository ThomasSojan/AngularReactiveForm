import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SkyHigh } from './skyHigh';
import { SkyHighService } from './sky-high.service';
import { JumpDateValidator } from './jumpDate-validator';


@Component({
  selector: 'app-sky-high',
  templateUrl: './sky-high.component.html',
  styleUrls: ['./sky-high.component.css']
})
export class SkyHighComponent implements OnInit { 


errorMessage: string; 
bookingForm:FormGroup;
booking: SkyHigh;
  

jumpHeightOptions : string[] = ["10,000 ft", "12,000 ft", "14,000 ft", "18,000 ft"]



  constructor(private fb : FormBuilder,private service: SkyHighService) { }
  
  ngOnInit() { 
    this.bookingForm = this.fb.group({
      name: ['', [Validators.required,Validators.pattern("^([A-Z][a-z]*)([ ][A-Z][a-z]*)?$")]],
      phoneNumber: ['', [Validators.required,Validators.min(1000000000),Validators.max(9999999999)]],
      jumbHeight:['',Validators.required],
      dateOfJumb:['',[Validators.required,JumpDateValidator.checkDateOfJump]]
 });
       
  }
 
  bookJump() {
    this.booking = null;
    this.errorMessage = null;
    this.service.book(this.bookingForm.value).subscribe(
      response=>{this.booking = response},
      error =>{this.errorMessage = error.error.message}
    )
  }

}
