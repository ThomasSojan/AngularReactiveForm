export class SkyHigh {
  
  jumpId:number;
	name:string;
  phoneNumber:number;
  jumpHeight:string;
  dateOfJump:Date;
 
}
