import { BookingSuccessPipe } from "src/app/sky-high/success.pipe";

describe('Structural | Pipe | bookingSuccessPipe', () => {

  it('Verifying the structure of BookingSuccessPipe', () => {
    expect(new BookingSuccessPipe()).toBeTruthy();
  });

});