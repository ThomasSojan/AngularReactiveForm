import { async, ComponentFixture, TestBed, tick, fakeAsync } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { ReactiveFormsModule, AbstractControl } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { DebugElement, PipeTransform, Pipe } from '@angular/core';
import { SkyHighService } from 'src/app/sky-high/sky-high.service';
import { SkyHighComponent } from 'src/app/sky-high/sky-high.component';
import { BookingSuccessPipe } from 'src/app/sky-high/success.pipe';

class SkyHighServiceStub
{
  book() { }
}
@Pipe({name : 'bookingSuccess'})
class BookingSuccessPipeStub implements PipeTransform
{
  transform(value: any)
  {
    return "Pipe";
  }
}
describe('Structural | Component | SkyHighComponent', () =>
{
  let component: SkyHighComponent;
  let fixture: ComponentFixture<SkyHighComponent>;
  let skyHighService: SkyHighService;

  beforeEach(async(() =>
  {
    TestBed.configureTestingModule
    ({
      imports : [RouterTestingModule, ReactiveFormsModule],
      declarations : [SkyHighComponent, BookingSuccessPipe],
      providers : [{provide : SkyHighService, useClass : SkyHighServiceStub}]
    }).compileComponents();
  }));

  beforeEach(() =>
  {
    fixture = TestBed.createComponent(SkyHighComponent);
    component = fixture.componentInstance;
    skyHighService = TestBed.get(SkyHighService);
    fixture.detectChanges();
    jasmine.MAX_PRETTY_PRINT_DEPTH = 2;
  });

  it('Verifying the Structure of SkyHighComponent', () =>
  {
    expect(component).toBeTruthy();
  });

  it('Verifying the structure of jumpHeightOptions', () =>
  {
    component.ngOnInit();

    let jumpHeightOptions = ["10,000 ft", "12,000 ft", "14,000 ft", "18,000 ft"];
    
    for (let jumpHeight of jumpHeightOptions)
    {
      expect(component.jumpHeightOptions).toContain(jumpHeight);
    }
  });


  describe('Testing the bookingForm', () =>
  {
    beforeEach(() =>
    {
      component.ngOnInit();
    });

    it("Verifying the structure of bookingForm ", () =>
    {
      expect(component.bookingForm).toBeDefined();
    });
  

  /* ---------------------- Form Fields : Binding ------------------------ */

  describe('bookingForm', () =>
  {
    let bookingFormTag: DebugElement;
    let nameInputTag: DebugElement;
     let dateInputTag: DebugElement;
    let phoneNumberInputTag: DebugElement;
    let jumpHeightInputTag: DebugElement;

    beforeEach(() =>
    {
      bookingFormTag = fixture.debugElement.query(By.css('form'));
      nameInputTag = fixture.debugElement.query(By.css('#name'));
     
        
      dateInputTag = fixture.debugElement.query(By.css('#dateOfJump'));
      phoneNumberInputTag = fixture.debugElement.query(By.css('#phoneNumber'));
      jumpHeightInputTag = fixture.debugElement.query(By.css('#jumpHeight'));

    });

    // it('should render booking in specific format', () => {
    //   const fixture = TestBed.createComponent(SkyHighComponent);
  
    //   // get the name's input and display elements from the DOM
    //   const bannerDe: DebugElement = fixture.debugElement;
  
    //   const bookingDisplay = bannerDe.query(By.css('.text-success'));
    //   const bookingDisplayEle: HTMLElement = bookingDisplay.nativeElement;
  
    //   // Tell Angular to update the display binding through the title pipe
    //   fixture.detectChanges();
  
    //   expect(bookingDisplayEle.textContent.trim()).toBe('Pipe');
    // });
  
    it('Verifying the structure of bookingForm | Testing whether the jumpHeight drop down is dynamic', () =>
    {
      let testJumpHeights = [
                                  ['10,000 ft'],
                                  ['10,000 ft', '12,000 ft'],
                                  ['10,000 ft', '12,000 ft', '14,000 ft'],
                                  ['10,000 ft', '12,000 ft', '14,000 ft', '18,000 ft']
                                ];
  
      for (let jumpHeightOptions of testJumpHeights)
      {
        component.jumpHeightOptions = jumpHeightOptions;
  
        fixture.detectChanges();
  
        let jumpHeightsOptions = fixture.debugElement.queryAll(By.css('option'));
  
        expect(jumpHeightsOptions.length).toBe(jumpHeightOptions.length + 1);
      }
    });








    it('Verifying the structure of bookingForm | Expecting FormGroup Binding to be accurate', () =>
    {
      expect(bookingFormTag.attributes['ng-reflect-form']).toBeTruthy();
    });

    it('Verifying the structure of booking | Expecting formControlName binding to be accurate for name', () =>
    {
      expect(nameInputTag.attributes['formControlName']).toBe('name');
    });



    it('Verifying the structure of bookingForm | Expecting formControlName binding to be accurate for  date', () =>
    {
      expect(dateInputTag.attributes['formControlName']).toBe('dateOfJump');
    });

    it('Verifying the structure of bookingForm | Expecting formControlName binding to be accurate for phoneNumber', () =>
    {
      expect(phoneNumberInputTag.attributes['formControlName']).toBe('phoneNumber');
    });

    it('Verifying the structure of internshipApplicationForm | Expecting formControlName binding to be accurate for internshipType', () =>
    {
      expect(jumpHeightInputTag.attributes['formControlName']).toBe('jumpHeight');
    });
  });




  /* ---------------------- Usage of appropriate Bootstrap classes ------------------------ */

  describe("bookingForm | Usage of Bootstrap Classes", () =>
  {
    let bookingFormTag: DebugElement;
    let nameInputTag: DebugElement;
     let dateInputTag: DebugElement;
    let phoneNumberInputTag: DebugElement;
    let jumpHeightInputTag: DebugElement;

    let nameErrorTag: DebugElement;
    let dateErrorTag: DebugElement;
    let phoneNumberErrorTag: DebugElement;
    let jumpHeightErrorTag: DebugElement;

    let bookJumpButtonTag: DebugElement;

    beforeEach(() =>
    {
      component.bookingForm.controls['name'].setValue(null);
        component.bookingForm.controls['dateOfJump'].setValue(null);
      component.bookingForm.controls['phoneNumber'].setValue(null);
      component.bookingForm.controls['jumpHeight'].setValue(null);

      component.bookingForm.controls['name'].markAsDirty();
        component.bookingForm.controls['dateOfJump'].markAsDirty();
      component.bookingForm.controls['phoneNumber'].markAsDirty();
      component.bookingForm.controls['jumpHeight'].markAsDirty();

      fixture.detectChanges();

      bookingFormTag = fixture.debugElement.query(By.css('form'));
      nameInputTag = fixture.debugElement.query(By.css("input[type='text']"));
        dateInputTag = fixture.debugElement.query(By.css('#dateOfJump'));
      phoneNumberInputTag = fixture.debugElement.query(By.css('#phoneNumber'));
      jumpHeightInputTag = fixture.debugElement.query(By.css('#jumpHeight'));

      nameErrorTag = fixture.debugElement.query(By.css('#nameError'));
      dateErrorTag = fixture.debugElement.query(By.css('#dateOfJumpError'));
      phoneNumberErrorTag = fixture.debugElement.query(By.css('#phoneNumberError'));
      jumpHeightErrorTag = fixture.debugElement.query(By.css('#jumpHeightError'));

      bookJumpButtonTag = fixture.debugElement.query(By.css('button'));
    });


    it("Verifying the structure of bookingForm | Expecting form-control class in name", () =>
    {
      expect(nameInputTag.attributes['class']).toContain('form-control');
    });

    it("Verifying the structure of bookingForm | Expecting form-group class in  name", () =>
    {
      expect(nameInputTag.parent.attributes['class']).toContain('form-group');
    });

  
    it("Verifying the structure of bookingForm | Expecting form-control class in date", () =>
    {
      expect(dateInputTag.attributes['class']).toContain('form-control');
    });

    it("Verifying the structure of bookingForm | Expecting form-group class in date", () =>
    {
      expect(dateInputTag.parent.attributes['class']).toBe('form-group');
    });

    it("Verifying the structure of bookingForm | Expecting form-control class in phoneNumber", () =>
    {
      expect(phoneNumberInputTag.attributes['class']).toContain('form-control');
    });

    it("Verifying the structure of bookingForm | Expecting form-group class in phoneNumber", () =>
    {
      expect(phoneNumberInputTag.parent.attributes['class']).toBe('form-group');
    });

    it("Verifying the structure of bookingForm | Expecting form-control class in jumpHeight", () =>
    {
      expect(jumpHeightInputTag.attributes['class']).toContain('form-control');
    });

    it("Verifying the structure of bookingForm | Expecting form-group class in jumpHeight", () =>
    {
      expect(jumpHeightInputTag.parent.attributes['class']).toBe('form-group');
    });

    it("Verifying the structure of bookingForm | Expecting btn class in bookJump", () =>
    {
      expect(bookJumpButtonTag.attributes['class']).toContain('btn');
    });

    it("Verifying the structure of bookingForm | Expecting text-danger class in nameError", () =>
    {
      expect(nameErrorTag.attributes['class']).toBe('text-danger');
    });

    it("Verifying the structure of bookingForm | Expecting text-danger class in dateError", () =>
    {
      expect(dateErrorTag.attributes['class']).toBe('text-danger');
    });

    it("Verifying the structure of bookingForm | Expecting text-danger class in phoneNumberError", () =>
    {
      expect(phoneNumberErrorTag.attributes['class']).toBe('text-danger');
    });

    it("Verifying the structure of bookingForm | Expecting text-danger class in jumpHeightError", () =>
    {
      expect(jumpHeightErrorTag.attributes['class']).toBe('text-danger');
    });
  })
  });
});
  
