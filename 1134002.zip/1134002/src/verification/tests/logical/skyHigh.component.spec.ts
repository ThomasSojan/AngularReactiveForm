import { async, ComponentFixture, TestBed, tick, fakeAsync } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { ReactiveFormsModule, AbstractControl } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { DebugElement, PipeTransform, Pipe } from '@angular/core';
import { SkyHighComponent } from 'src/app/sky-high/sky-high.component';
import { SkyHighService } from 'src/app/sky-high/sky-high.service';
import { of, throwError } from 'rxjs';
import { HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { BookingSuccessPipe } from 'src/app/sky-high/success.pipe';
import {SkyHigh as Sky} from 'src/app/sky-high/skyHigh';

class SkyHighServiceStub
{
  book() { }
}

describe('Logical | Component | SkyHighComponent', () =>
{
  let component: SkyHighComponent;
  let fixture: ComponentFixture<SkyHighComponent>;
  let skyHighService: SkyHighService;

  beforeEach(async(() =>
  {
    TestBed.configureTestingModule
    ({
      imports : [RouterTestingModule, ReactiveFormsModule],
      declarations : [SkyHighComponent, BookingSuccessPipe],
      providers : [{provide : SkyHighService, useClass : SkyHighServiceStub}]
    }).compileComponents();
  }));

  beforeEach(() =>
  {
    fixture = TestBed.createComponent(SkyHighComponent);
    component = fixture.componentInstance;
    skyHighService = TestBed.get(SkyHighService);
    fixture.detectChanges();
    jasmine.MAX_PRETTY_PRINT_DEPTH = 2;
  });

  it('Verifying the functionality of SkyHighComponent | Check wether SkyHighComponent is defined', () =>
  {
    expect(component).toBeTruthy();
  });

  //  it('1-TSC 2/84 - SkyHighComponent: booking should be populated', () =>
  //  {
  //    component.bookJump();
  //    let date: Date = new Date("2030-01-16");
  //   let booking1: Sky ={jumpId: 1003,name: "Akjsksd",
  //    phoneNumber: 7384737473, jumpHeight: "14,000 ft", date: date};
  //    let booking = booking1; 
    
  // //   for (let internshipType of internshipTypeList)
  // //   {
  //     expect(component.booking).toContain(booking);
  // //   }
  //  });

  describe('ngOnInit', () =>
  {
    beforeEach(() =>
    {
      component.ngOnInit();
    });

    it("Verifying the functionality of bookingForm | Check wether bookingForm is defined", () =>
    {
      expect(component.bookingForm).toBeDefined();
    });


    /* ---------------------- Form Field 1 : internName ------------------------ */

    describe('name', () =>
    {
      let errors;
      let name: AbstractControl;
      let nameErrorSpan;

      beforeEach(() =>
      {
        name = component.bookingForm.controls['name'];
        name.setValue('');
        errors = name.errors;
        fixture.detectChanges();
        nameErrorSpan = fixture.debugElement.query(By.css('#nameError'));
      });

      it('Verifying the functionality of bookingForm | name should be invalid if it is empty', () =>
      {
        expect(name.valid).toBeFalsy();
      });

      it('Verifying the functionality of bookingForm | name should contain required error if it is empty', () =>
      {
        expect(errors['required']).toBeTruthy();
      });

      it('Verifying the functionality of bookingForm | nameError should not be displayed initially', () =>
      {
        expect(nameErrorSpan).toBeFalsy();
      });
    });

    describe('Valid', () =>
    {
      let errors;
      let name;
      let nameErrorSpan;

      beforeEach(() =>
      {
        name = component.bookingForm.controls['name'];
        name.setValue("Dan Cooper");
        name.markAsDirty();
        errors = name.errors;
        fixture.detectChanges();
        nameErrorSpan = fixture.debugElement.query(By.css('#nameError'));
      });

      it('Verifying the functionality of bookingForm | name should be valid  | Dan Cooper', () =>
      {
        expect(name.valid).toBeTruthy();
      });

      it('Verifying the functionality of bookingForm | name should not contain error | Dan Cooper', () =>
      {
        expect(errors).toBeFalsy();
      });

      it('Verifying the functionality of bookingForm | nameError should not be displayed initially', () =>
      {
        expect(nameErrorSpan).toBeFalsy();
      })
    });

    describe('Invalid', () =>
    {
      let errors;
      let name;
      let nameErrorSpan;

      beforeEach(() =>
      {
        name = component.bookingForm.controls['name'];
        name.setValue("Akankasha sharma");
        name.markAsDirty();
        errors = name.errors;
        fixture.detectChanges();
        nameErrorSpan = fixture.debugElement.query(By.css('#nameError'));
      });

      it('Verifying the functionality of bookingForm | name should be invalid | Akankasha sharma', () =>
      {
        expect(name.invalid).toBeTruthy();
      });

      it('Verifying the functionality of bookingForm | namePattern should be invalid | Akankasha sharma', () =>
      {
        expect(errors['pattern']).toBeTruthy();
      });

      it('Verifying the functionality of bookingForm | nameError should be displayed| Akankasha sharma', () =>
      {
        expect(nameErrorSpan).toBeTruthy();
      });
    });


  
    /* ---------------------- Form Field 3 : date ------------------------ */

    describe('dateOfJump', () =>
    {
      let errors;
      let dateOfJump: AbstractControl;
      let dateOfJumpErrorSpan;

      beforeEach(() =>
      {
        dateOfJump = component.bookingForm.controls['dateOfJump'];
        dateOfJump.setValue('');
        errors = dateOfJump.errors;
        fixture.detectChanges();
        dateOfJumpErrorSpan = fixture.debugElement.query(By.css('#dateOfJumpError'));
      });

      it('Verifying the functionality of dateForm | date should be invalid if it is empty', () =>
      {
        expect(dateOfJump.valid).toBeFalsy();
      });

      it('Verifying the functionality of bookingForm | date should contain required error if it is empty', () =>
      {
        expect(errors['required']).toBeTruthy();
      });

      describe('dateOfJump field which is current or a past date', () => { 
        let errors;
        let dateOfJump: AbstractControl;
        let dateOfJumpSpan;
        let date: Date = new Date("2020-01-16");

        beforeEach(() => {
          dateOfJump = component.bookingForm.controls['dateOfJump'];
          dateOfJump.setValue(date);
          dateOfJump.markAsDirty();
          errors = dateOfJump.errors;
          fixture.detectChanges();
          dateOfJumpSpan = fixture.debugElement.query(By.css('#dateOfJumpError'));
        });
  
        it('TSC - dateOfJump should be invalid if it is current or past', () => {
          expect(dateOfJump.valid).toBeFalsy();
        });
  
        it('TSC - dateOfJump should contain error if it is current or past', () => {
          expect(errors).toBeTruthy();
  
        });
  
        it('TSC - dateOfJump should display the error message if it is current or past', () => {
          expect(dateOfJumpSpan).toBeTruthy();
        })
      });

      it('Verifying the functionality of bookingForm | dateError should not be displayed initially', () =>
      {
        expect(dateOfJumpErrorSpan).toBeFalsy();
      });
    });

    describe('Valid', () =>
    {
      let errors;
      let date;
      let dateErrorSpan;

      beforeEach(() =>
      {  
        let d= new Date(2030, 11, 17);
        date = component.bookingForm.controls['dateOfJump'];
        date.setValue(d);
        date.markAsDirty();
        errors = date.errors;
        fixture.detectChanges();
        dateErrorSpan = fixture.debugElement.query(By.css('#dateOfJumpError'));
      });

       it('Verifying the functionality of bookingForm | Expecting date to be valid for d', () =>
       {
         expect(date.valid).toBeTruthy();
       });

       it('Verifying the functionality of bookingForm | Expecting date to not contain required error when it is valid', () =>
       {
         expect(errors).toBeFalsy();
       });

       it('Verifying the functionality of bookingForm | Expecting dateError to be not displayed when valid', () =>
       {
         expect(dateErrorSpan).toBeFalsy();
       });
     });

    describe('Invalid', () =>
    {
      let errors;
      let date;
      let dateErrorSpan;

      beforeEach(() =>
      {
        date = component.bookingForm.controls['dateOfJump'];
        date.setValue(null);
        date.markAsDirty();
        errors = date.invalid;
        fixture.detectChanges();
        dateErrorSpan = fixture.debugElement.query(By.css('#dateOfJumpError'));
      });

      it("Verifying the functionality of bookingForm | Expecting date to be invalid for '01-01'", () =>
      {
        expect(date.valid).toBeFalsy();
      });

      it("Verifying the functionality of bookingForm | Expecting date to contain 'required' error when it is invalid", () =>
      {
        expect(errors).toBeTruthy();
      });

      it('Verifying the functionality of bookingForm | Expecting dateError to be displayed when invalid', () =>
      {
        expect(dateErrorSpan).toBeTruthy();
      });
    });
    

    /* ---------------------- Form Field 4 : mobileNumber ------------------------ */

    describe('phoneNumber', () =>
    {
      let errors;
      let phoneNumber: AbstractControl;
      let phoneNumberErrorSpan;

      beforeEach(() =>
      {
        phoneNumber = component.bookingForm.controls['phoneNumber'];
        phoneNumber.setValue('');
        errors = phoneNumber.errors;
        fixture.detectChanges();
        phoneNumberErrorSpan = fixture.debugElement.query(By.css('#phonbeNumberError'));
      });

      it('Verifying the functionality of bookingForm | Expecting phoneNumber to be invalid when it is empty', () =>
      {
        expect(phoneNumber.valid).toBeFalsy();
      });

      it("Verifying the functionality of bookingForm | Expecting phoneNumber to contain 'required' error when it is empty", () =>
      {
        expect(errors['required']).toBeTruthy();
      });

      it("Verifying the functionality of bookingForm | Expecting phoneNumberError to be not displayed initially", () =>
      {
        expect(phoneNumberErrorSpan).toBeFalsy();
      });
    });

    describe('Valid', () =>
    {
      let errors;
      let phoneNumber: AbstractControl;
      let phoneNumberErrorSpan;

      beforeEach(() =>
      {
        phoneNumber = component.bookingForm.controls['phoneNumber'];
        phoneNumber.setValue('8568593343');
        phoneNumber.markAsDirty();
        errors = phoneNumber.errors;
        fixture.detectChanges();
        phoneNumberErrorSpan = fixture.debugElement.query(By.css('#phoneNumberError'));
      });

      it('Verifying the functionality of bookingForm | Expecting phoneNumber to be valid for 8568593343', () =>
      {
        expect(phoneNumber.valid).toBeTruthy();
      });

      it("Verifying the functionality of bookingForm | Expecting phoneNumber to not contain 'required' error when it is valid", () =>
      {
        expect(errors).toBeFalsy();
      });

      it("Verifying the functionality of bookingForm | Expecting phoneNumberError to be not displayed when valid", () =>
      {
        expect(phoneNumberErrorSpan).toBeFalsy();
      });
    });

    describe('Invalid', () =>
    {
      let errors;
      let phoneNumber: AbstractControl;
      let phoneNumberErrorSpan;

      beforeEach(() =>
      {
        phoneNumber = component.bookingForm.controls['phoneNumber'];
        phoneNumber.setValue('98568778');
        phoneNumber.markAsDirty();
        errors = phoneNumber.errors;
        fixture.detectChanges();
        phoneNumberErrorSpan = fixture.debugElement.query(By.css('#phoneNumberError'));
      });

      it('Verifying the functionality of bookingForm | Expecting phoneNumber to be invalid for 98568778', () =>
      {
        expect(phoneNumber.valid).toBeFalsy();
      });

      it("Verifying the functionality of bookingForm | Expecting phoneNumber to contain 'required' error when it is invalid", () =>
      {
        expect(errors).toBeTruthy();
      });

      it('Verifying the functionality of bookingForm | Expecting phoneNumberError to be displayed when invalid', () =>
      {
        expect(phoneNumberErrorSpan).toBeTruthy();
      });
    });


    /* ---------------------- Form Field 5 : jumpHeight ------------------------ */

    describe('jumpHeight', () =>
    {
      let errors;
      let jumpHeight: AbstractControl;
      let jumpHeightErrorSpan;

      beforeEach(() =>
      {
        jumpHeight = component.bookingForm.controls['jumpHeight'];
        jumpHeight.setValue('');
        errors = jumpHeight.errors;
        fixture.detectChanges();
        jumpHeightErrorSpan = fixture.debugElement.query(By.css('#jumpHeightError'));
      });

      it('Verifying the functionality of bookingForm | Expecting jumpHeight to be invalid when it is empty', () =>
      {
        expect(jumpHeight.valid).toBeFalsy();
      });

      it("Verifying the functionality of bookingForm | Expecting jumpHeight to contain 'required' error when it is empty", () =>
      {
        expect(errors['required']).toBeTruthy();
      });

      it("Verifying the functionality of bookingForm | Expecting jumpHeightError to be not displayed initially", () =>
      {
        expect(jumpHeightErrorSpan).toBeFalsy();
      });
    });

    describe('Valid', () =>
    {
      let errors;
      let jumpHeight: AbstractControl;
      let jumpHeightErrorSpan;

      beforeEach(() =>
      {
        jumpHeight = component.bookingForm.controls['jumpHeight'];
        jumpHeight.setValue('12,000 ft');
        jumpHeight.markAsDirty();
        errors = jumpHeight.errors;
        fixture.detectChanges();
        jumpHeightErrorSpan = fixture.debugElement.query(By.css('#jumpHeightError'));
      });

      it("Verifying the functionality of bookingForm | Expecting jumpHeight to be valid for '12,000 ft'", () =>
      {
        expect(jumpHeight.valid).toBeTruthy();
      });

      it("Verifying the functionality of bookingForm | Expecting jumpHeight to not contain 'required' error when it is valid", () =>
      {
        expect(errors).toBeFalsy();
      });

      it("Verifying the functionality of bookingForm | Expecting jumpHeightError to be not displayed when valid", () =>
      {
        expect(jumpHeightErrorSpan).toBeFalsy();
      });
    });

    describe('Invalid', () =>
    {
      let errors;
      let jumpHeight: AbstractControl;
      let jumpHeightErrorSpan;

      beforeEach(() =>
      {
        jumpHeight = component.bookingForm.controls['jumpHeight'];
        jumpHeight.setValue('');
        jumpHeight.markAsDirty();
        errors = jumpHeight.errors;
        fixture.detectChanges();
        jumpHeightErrorSpan = fixture.debugElement.query(By.css('#jumpHeightError'));
      });

      it("Verifying the functionality of jumpHeight | Expecting jumpHeight to be invalid for ''", () =>
      {
        expect(jumpHeight.valid).toBeFalsy();
      });

      it("Verifying the functionality of bookingForm | Expecting jumpHeight to contain 'required' error when it is invalid", () =>
      {
        expect(errors['required']).toBeTruthy();
      });

      it("Verifying the functionality of bookingForm | Expecting jumpHeightError to be displayed when invalid", () =>
      {
        expect(jumpHeightErrorSpan).toBeTruthy();
      });
    });
  });

  /* ---------------------- Submit applyButton : Apply ------------------------ */

  describe('bookingForm |Book Jump button| Invalid', () =>
  {
    let bookJumpButton;

    beforeEach(() =>
    {
      component.bookingForm.controls['name'].setValue("prashi sachan");
     // component.internshipApplicationForm.controls['gender'].setValue('M');
      component.bookingForm.controls['dateOfJump'].setValue('2000-06-21');
      component.bookingForm.controls['phoneNumber'].setValue('9089876');
      component.bookingForm.controls['jumpHeight'].setValue('1400 ft');

      component.bookingForm.markAsDirty();

      fixture.detectChanges();

      bookJumpButton = fixture.debugElement.query(By.css('button')).nativeElement;
    });

    it('Verifying the functionality of bookingForm | Form should be invalid', () =>
    {
      expect(component.bookingForm.invalid).toBe(true);
    });

    it('Verifying the functionality of bookingForm | Submit apply should be disabled', () =>
    {
      expect(bookJumpButton.disabled).toBe(true);
    });
  });

  describe('bookingForm |Book Jump button| Valid', () =>
  {
    let bookJumpButton;

    beforeEach(() =>
    {
      component.bookingForm.controls['name'].setValue("Hema Morusu");
     
     
     // component.internshipApplicationForm.controls['gender'].setValue('F');
      component.bookingForm.controls['dateOfJump'].setValue('2030-02-02');
      component.bookingForm.controls['phoneNumber'].setValue('6910190374');
      component.bookingForm.controls['jumpHeight'].setValue('14,000 ft');

      component.bookingForm.markAsDirty();

      fixture.detectChanges();

      bookJumpButton = fixture.debugElement.query(By.css('button')).nativeElement;
    });

    it('Verifying the functionality of bookingForm | Form should be valid', () =>
    {
      expect(component.bookingForm.valid).toBe(true);
    });

    it('Verifying the functionality of bookingForm | book jump should be enabled', () =>
    {
      expect(bookJumpButton.disabled).toBe(false);
    });

    it('Verifying the functionality of bookingForm | bookJump function should be called on bookJump', () =>
    {
      const spy = spyOn(component, 'bookJump').and.returnValue(null);
      bookJumpButton.click();
      expect(spy).toHaveBeenCalled();
    });
  });

  /* ---------------------- Form Fields : Binding ------------------------ */

  describe('Testing the binding of form fields', () =>
  {
    let bookingFormTag: DebugElement;
    let nameInputTag: DebugElement;
  //  let genderInputTag: DebugElement[];
    let dateInputTag: DebugElement;
    let phoneNumberInputTag: DebugElement;
    let jumpHeightInputTag: DebugElement;

    beforeEach(() =>
    {
      bookingFormTag = fixture.debugElement.query(By.css('form'));
      nameInputTag = fixture.debugElement.query(By.css('#name'));
     
     
     // genderInputTag = fixture.debugElement.queryAll(By.css("input[type='radio']"));
      dateInputTag = fixture.debugElement.query(By.css('#dateOfJump'));
      phoneNumberInputTag = fixture.debugElement.query(By.css('#phoneNumber'));
      jumpHeightInputTag = fixture.debugElement.query(By.css('#jumpHeight'));

    });

    it('0.5-TSC 51/84 - Testing the binding of formGroup to form tag', () =>
    {
      expect(bookingFormTag.attributes['ng-reflect-form']).toBeTruthy();
    });

    it('0.25-TSC 52/84 - Testing formControlName binding for name', () =>
    {
      expect(nameInputTag.attributes['formControlName']).toBe('name');
    });

    // it('0.25-TSC 53/84 - Testing formControlName binding for gender', () =>
    // {
    //   let genderCount = 0;

    //   for (let element of genderInputTag)
    //   {
    //     if (element.attributes['formControlName'] == 'gender')
    //     {
    //       genderCount++;
    //     }
    //   }

    //   expect(genderCount).toBe(3);
    // });

    it('0.25-TSC 54/84 - Testing formControlName binding for date', () =>
    {
      expect(dateInputTag.attributes['formControlName']).toBe('dateOfJump');
    });

    it('0.25-TSC 55/84 - Testing formControlName binding for phoneNumber', () =>
    {
      expect(phoneNumberInputTag.attributes['formControlName']).toBe('phoneNumber');
    });

    it('0.25-TSC 56/84 - Testing formControlName binding for jumpHeight', () =>
    {
      expect(jumpHeightInputTag.attributes['formControlName']).toBe('jumpHeight');
    });
  });

  /* ---------------------- Component : bookJump() ------------------------ */

  describe("bookJump", () =>
  {
    let fakeSuccessResponseObject;
    let fakeErrorResponseObject;
    let date1: Date = new Date("2030-01-01"); 
    beforeEach(() =>
    {
      fakeSuccessResponseObject = {
      jumpId: 1003,name: "Saki Moni",
      phoneNumber: 9110918237, jumpHeight: "12,000 ft", dateOfJump: date1
      }
         
      
    
      fakeErrorResponseObject = new HttpErrorResponse
                                ({
                                  error :
                                  {
                                    message : "Sorry!"
                                  }
                                });
      
      component.bookingForm.controls['name'].setValue("Saki Moni");
     // component.internshipApplicationForm.controls['gender'].setValue('F');
      component.bookingForm.controls['dateOfJump'].setValue('2030-01-01');
      component.bookingForm.controls['phoneNumber'].setValue('9110918237');
      component.bookingForm.controls['jumpHeight'].setValue('12,000 ft');

      fixture.detectChanges();
    })

    it("Verifying the functionality of bookingForm | Expecting SkyHighComponent.bookJump() to call SkyHighService.book()", () =>
    {
      const spy = spyOn(skyHighService,"book").and.returnValue(of(fakeSuccessResponseObject));
      component.bookJump();
      expect(spy).toHaveBeenCalled();
    })

    it("Verifying the functionality of bookingForm | Expecting SkyHighComponent.bookJump() to call SkyHighService.book() with accurate data", () =>
    {
      const spy = spyOn(skyHighService, "book").and.returnValue(of(fakeSuccessResponseObject));
      component.bookJump();
      expect(spy).toHaveBeenCalledWith(component.bookingForm.value);
    })

    
    let booking: Sky = {jumpId: 1003,name: "Saki Moni",
    phoneNumber: 9110918237, jumpHeight: "12,000 ft", dateOfJump: date1
    };
    it("Verifying the functionality of bookingForm | Expecting successMessage to be populated on positive response", fakeAsync(() =>
    {
      spyOn(skyHighService, "book").and.returnValue(of(fakeSuccessResponseObject));
      component.bookJump();
      tick();
      expect(component.booking).toEqual(booking);
    }))

    it("Verifying the functionality of internshipApplicationForm | Expecting errorMessage to be populated on negative response", fakeAsync(() =>
    {
      spyOn(skyHighService, "book").and.returnValue(throwError(fakeErrorResponseObject));
      component.bookJump();
      tick();
      expect(component.errorMessage).toEqual("Sorry!");
    }));
  });

  /* ---------------------- Static Population : gender ------------------------ */

  // describe("Testing the statically populated gender radio", () =>
  // {
  //   let genderRadio : DebugElement[];

  //   beforeEach(() =>
  //   {
  //     fixture.detectChanges();
  //     genderRadio = fixture.debugElement.queryAll(By.css("input[type='radio']"));
  //   })

  //   it("1-TSC 62/84 - Testing the values of gender radio", () =>
  //   {
  //     let genderCount = 0;

  //     for (let element of genderRadio)
  //     {
  //       if (element.nativeElement.value == 'M' || element.nativeElement['ng-reflect-value'] == 'M')
  //       {
  //         genderCount++;
  //       }

  //       if (element.nativeElement.value == 'F' || element.nativeElement['ng-reflect-value'] == 'F')
  //       {
  //         genderCount++;
  //       }

  //       if (element.nativeElement.value == 'O' || element.nativeElement['ng-reflect-value'] == 'O')
  //       {
  //         genderCount++;
  //       }
  //     }

  //     expect(genderCount).toBe(3);
  //   });
  // });

  /* ---------------------- Dynamic Population : jumpHeight ------------------------ */

  describe("Testing the dynamically populated jumpHeight drop down", () =>
  {
    let jumpHeightDropDown : DebugElement;
    let jumpHeightOptions : DebugElement[];

    beforeEach(() =>
    {
      fixture.detectChanges();
      jumpHeightDropDown = fixture.debugElement.query(By.css("select"));
      jumpHeightOptions = jumpHeightDropDown.children;
    })

    it("0.25-TSC 63/84 - Testing the presence of default value", () =>
    {
      let defaultValueCount = 0;

      for (let element of jumpHeightOptions)
      {
        if (element.nativeElement.value == '' || element.nativeElement['ng-reflect-value'] == '')
        {
          if (element.nativeElement.innerHTML.toLowerCase().replace(/ /gi, '') == '--selectaheight--')
          {
            defaultValueCount++;
          }
        }
      }

      expect(defaultValueCount).toBe(1);
    });

    it("1-TSC 64/84 - Testing the values of jumpHeight drop down", () =>
    {
      let jumpHeightCount = 0;

      for (let element of jumpHeightOptions)
      {
        if (element.nativeElement.value == '10,000 ft' || element.nativeElement['ng-reflect-value'] == '10,000 ft')
        {
          jumpHeightCount++;
        }

        if (element.nativeElement.value == '12,000 ft' || element.nativeElement['alue'] == '12,000 ft')
        {
          jumpHeightCount++;
        }

        if (element.nativeElement.value == '14,000 ft' || element.nativeElement['ng-reflect-value'] == '14,000 ft')
        {
          jumpHeightCount++;
        }

        if (element.nativeElement.value == '18,000 ft' || element.nativeElement['ng-reflect-value'] == '18,000 ft')
        {
          jumpHeightCount++;
        }
      }

      expect(jumpHeightCount).toBe(4);
    });
  });

  /* ---------------------- Usage of appropriate Bootstrap classes ------------------------ */

  //  describe("Testing whether appropriate bootstrap classes are used", () =>
  //  {
  //    let bookingFormTag: DebugElement;
  //   let internNameInputTag: DebugElement;
  //  // let genderInputTag: DebugElement[];
  //   let emailInputTag: DebugElement;
  //   let mobileNumberInputTag: DebugElement;
  //   let internshipTypeInputTag: DebugElement;

  //   let internNameErrorTag: DebugElement;
  //   let emailErrorTag: DebugElement;
  //   let mobileNumberErrorTag: DebugElement;
  //   let internshipTypeErrorTag: DebugElement;

  //   let applyButtonTag: DebugElement;

  //   beforeEach(() =>
  //   {
  //     component.internshipApplicationForm.controls['internName'].setValue(null);
  //    // component.internshipApplicationForm.controls['gender'].setValue(null);
  //     component.internshipApplicationForm.controls['email'].setValue(null);
  //     component.internshipApplicationForm.controls['mobileNumber'].setValue(null);
  //     component.internshipApplicationForm.controls['internshipType'].setValue(null);

  //     component.internshipApplicationForm.controls['internName'].markAsDirty();
  //    // component.internshipApplicationForm.controls['gender'].markAsDirty();
  //     component.internshipApplicationForm.controls['email'].markAsDirty();
  //     component.internshipApplicationForm.controls['mobileNumber'].markAsDirty();
  //     component.internshipApplicationForm.controls['internshipType'].markAsDirty();

  //     fixture.detectChanges();

   //    bookingFormTag = fixture.debugElement.query(By.css('form'));
  //     internNameInputTag = fixture.debugElement.query(By.css("input[type='text']"));
  //    // genderInputTag = fixture.debugElement.queryAll(By.css("input[type='radio']"));
  //     emailInputTag = fixture.debugElement.query(By.css('#email'));
  //     mobileNumberInputTag = fixture.debugElement.query(By.css('#mobileNumber'));
  //     internshipTypeInputTag = fixture.debugElement.query(By.css('#internshipType'));

  //     internNameErrorTag = fixture.debugElement.query(By.css('#internNameError'));
  //     emailErrorTag = fixture.debugElement.query(By.css('#emailError'));
  //     mobileNumberErrorTag = fixture.debugElement.query(By.css('#mobileNumberError'));
  //     internshipTypeErrorTag = fixture.debugElement.query(By.css('#internshipTypeError'));

  //     applyButtonTag = fixture.debugElement.query(By.css('button'));
  //   });

    //  it("0.2-TSC 65/84 - Usage of form class", () =>
    //  {
    //    expect(bookingFormTag.attributes['class']).toContain('form');
    //  });

  //   it("0.2-TSC 66/84 - Usage of form-control class in internNameInputTag", () =>
  //   {
  //     expect(internNameInputTag.attributes['class']).toContain('form-control');
  //   });

  //   it("0.2-TSC 67/84 - Usage of form-group class around internNameInputTag", () =>
  //   {
  //     expect(internNameInputTag.parent.attributes['class']).toContain('form-group');
  //   });

  //   // it("0.2-TSC 68/84 - Usage of form-check-input class in genderInputTag", () =>
  //   // {
  //   //   for (let genderElement of genderInputTag)
  //   //   {
  //   //     expect(genderElement.attributes['class']).toBe('form-check-input');
  //   //   }
  //   // });

  //   // it("0.1-TSC 69/84 - Usage of form-check-label class around genderInputTag", () =>
  //   // {
  //   //   for (let genderElement of genderInputTag)
  //   //   {
  //   //     expect(genderElement.parent.attributes['class']).toBe('form-check-label');
  //   //   }
  //   // });

  //   // it("0.1-TSC 70/84 - Usage of form-check class around genderInputTag", () =>
  //   // {
  //   //   for (let genderElement of genderInputTag)
  //   //   {
  //   //     expect(genderElement.parent.parent.attributes['class']).toContain('form-check');
  //   //   }
  //   // });

  //   // it("0.2-TSC 71/84 - Usage of form-check-inline class around genderInputTag", () =>
  //   // {
  //   //   for (let genderElement of genderInputTag)
  //   //   {
  //   //     expect(genderElement.parent.parent.attributes['class']).toContain('form-check-inline');
  //   //   }
  //   // });

  //   it("0.2-TSC 72/84 - Usage of form-control class in emailInputTag", () =>
  //   {
  //     expect(emailInputTag.attributes['class']).toContain('form-control');
  //   });

  //   it("0.2-TSC 73/84 - Usage of form-group class around emailInputTag", () =>
  //   {
  //     expect(emailInputTag.parent.attributes['class']).toBe('form-group');
  //   });

  //   it("0.2-TSC 74/84 - Usage of form-control class in mobileNumberInputTag", () =>
  //   {
  //     expect(mobileNumberInputTag.attributes['class']).toContain('form-control');
  //   });

  //   it("0.2-TSC 75/84 - Usage of form-group class around mobileNumberInputTag", () =>
  //   {
  //     expect(mobileNumberInputTag.parent.attributes['class']).toBe('form-group');
  //   });

  //   it("0.2-TSC 76/84 - Usage of form-control class in internshipTypeInputTag", () =>
  //   {
  //     expect(internshipTypeInputTag.attributes['class']).toContain('form-control');
  //   });

  //   it("0.2-TSC 77/84 - Usage of form-group class around internshipTypeInputTag", () =>
  //   {
  //     expect(internshipTypeInputTag.parent.attributes['class']).toBe('form-group');
  //   });

  //   it("0.5-TSC 78/84 - Usage of btn classes in applyButton", () =>
  //   {
  //     expect(applyButtonTag.attributes['class']).toContain('btn');
  //   });

  //   it("0.5-TSC 79/84 - Usage of text-danger class in internNameErrorTag", () =>
  //   {
  //     expect(internNameErrorTag.attributes['class']).toBe('text-danger');
  //   });

  //   it("0.5-TSC 80/84 - Usage of text-danger class in emailErrorTag", () =>
  //   {
  //     expect(emailErrorTag.attributes['class']).toBe('text-danger');
  //   });

  //   it("0.5-TSC 81/84 - Usage of text-danger class in mobileNumberErrorTag", () =>
  //   {
  //     expect(mobileNumberErrorTag.attributes['class']).toBe('text-danger');
  //   });

  //   it("0.5-TSC 82/84 - Usage of text-danger class in internshipTypeErrorTag", () =>
  //   {
  //     expect(internshipTypeErrorTag.attributes['class']).toBe('text-danger');
  //   });
  // })

  /* ---------------------- Display of success and error messages ------------------------ */

  describe('bookingForm | Success and Error Messages', () =>
  {

    let successMessageTag : DebugElement;
    let errorMessageTag: DebugElement;

    it('Verifying the functionality of bookingForm | Expecting error message to be displayed', () =>
    {
      component.errorMessage = "Sorry!";
      component.booking = null;

      fixture.detectChanges();
      
      errorMessageTag = fixture.debugElement.query(By.css('div .text-danger'));

      expect(errorMessageTag.nativeElement.innerHTML).toContain("Sorry!");
    });

    it('Verifying the functionality of bookingForm | Expecting booking to be displayed', () =>
    {
       
      let date: Date = new Date("2030-01-16");
      let booking: Sky ={jumpId: 1003,name: "Akjsksd",phoneNumber: 7384737473, jumpHeight: "14,000 ft", dateOfJump: date};
      component.booking = booking;
      
      component.errorMessage = null;

      fixture.detectChanges();
      
      successMessageTag = fixture.debugElement.query(By.css('div .text-success'));

      expect(successMessageTag.nativeElement.innerHTML).toContain("Thanks");
    });
  });
});
