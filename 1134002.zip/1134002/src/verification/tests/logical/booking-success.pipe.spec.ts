import { BookingSuccessPipe } from 'src/app/sky-high/success.pipe';
import {SkyHigh as Sky} from 'src/app/sky-high/skyHigh';
describe('Structural | Pipe | BookingSuccessPipe', () =>
{
  let pipe : BookingSuccessPipe;

  beforeEach(() =>
  {
    pipe = new BookingSuccessPipe();
  })

  it('Verifying the structure of BookingSuccessPipe', () =>
  {
    expect(pipe).toBeTruthy();
  });

  it('Verifying the return value of BookingSuccessPipe for input : booking', () =>
  { 
    let date: Date = new Date("2030-01-16");
    let booking: Sky ={jumpId: 1003,name: "Akjsksd",phoneNumber: 7384737473, jumpHeight: "14,000 ft", dateOfJump: date};
    let returnValue = pipe.transform(booking);
   //returnValue = returnValue.toLowerCase().replace(/ /gi, "");
    expect(returnValue).toBe("Thanks for choosing us : Your jump is scheduled on "+booking.dateOfJump+" with id as "+booking.jumpId)
  })

  it('Verifying the return value of BookingSuccessPipe for input : ', () =>
  { 
    let date: Date = new Date("2030-01-16");
    let booking: Sky ={jumpId: 1005,name: "Akjsksd",phoneNumber: 7384737474, jumpHeight: "12,000 ft", dateOfJump: date}
    let returnValue = pipe.transform(booking);
   // returnValue = returnValue.toLowerCase().replace(/ /gi, "");
    expect(returnValue).toBe("Thanks for choosing us : Your jump is scheduled on "+booking.dateOfJump+" with id as "+booking.jumpId)
  })

});