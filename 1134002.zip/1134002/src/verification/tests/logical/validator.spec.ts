import { JumpDateValidator } from "../../../app/sky-high/jumpDate-validator";
import { FormControl } from '@angular/forms';

describe("jumpDateValidator", ()=>{

    it("TCV - JumpDateValidator checkDateOfJump method check for valid value: ", ()=>{
        let date: Date = new Date("2030-01-16");
        let control: FormControl = new FormControl();
        control.setValue(date);
        expect(JumpDateValidator.checkDateOfJump(control)).toBe(null);
    })

    it("TCV - JumpDateValidator checkDate method check for invalid value:", ()=>{
        let control: FormControl = new FormControl();
        let date: Date = new Date()
        control.setValue(date);
        expect(JumpDateValidator.checkDateOfJump(control)).toEqual({checkDate:true});
    })

    it("TCV - JumpDateValidator checkDate method check for invalid value: ", ()=>{
        let control: FormControl = new FormControl();
        let date: Date = new Date("2020-01-16");
        control.setValue(date);
        expect(JumpDateValidator.checkDateOfJump(control)).toEqual({checkDate: true});
    })
})